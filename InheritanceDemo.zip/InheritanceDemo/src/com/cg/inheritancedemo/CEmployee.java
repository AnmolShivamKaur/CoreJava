package com.cg.inheritancedemo;

public final class CEmployee extends Employee {
	private int variablePay,totalSalary;
	private String signContract;
	public CEmployee() {
		super();
	}
	public CEmployee(int employeeId, String firstName, String lastname,
			int basicSalary) {
		super(employeeId, firstName, lastname, basicSalary);
	}
	public CEmployee(int variablePay, String signContract) {
		super();
		this.variablePay = variablePay;
		this.signContract = signContract;
	}
	public int getVariablePay() {
		return variablePay;
	}
	public void setVariablePay(int variablePay) {
		this.variablePay = variablePay;
	}
	public int getTotalSalary() {
		return totalSalary;
	}
	public void setTotalSalary(int totalSalary) {
		this.totalSalary = totalSalary;
	}
	public void signContract() {
		System.out.println("Contract was signed");
	}
	public void calculateTotalSalary(){
		this.totalSalary=this.getVariablePay();
	}

	@Override
	public String toString() {
		return super.toString()+"variablePay=" + variablePay + ", totalSalary="
				+ totalSalary ;
	}

}
