package com.cg.inheritancedemo;

public abstract class Employee {
	private int employeeId;
	private String firstName,lastname;
	private int basicSalary,totalSalary;

	public Employee() {
		super();
	}

	public Employee(int employeeId, String firstName, String lastname,
			int basicSalary) {
		super();
		this.employeeId = employeeId;
		this.firstName = firstName;
		this.lastname = lastname;
		this.basicSalary = basicSalary;
	}

	public int getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastname() {
		return lastname;
	}
	public void setLastname(String lastname) {
		this.lastname = lastname;
	}
	public int getBasicSalary() {
		return basicSalary;
	}
	public void setBasicSalary(int basicSalary) {
		this.basicSalary = basicSalary;
	}
	public int getTotalSalary() {
		return totalSalary;
	}
	public void setTotalSalary(int totalSalary) {
		this.totalSalary = totalSalary;
	}
	public void calculateTotalSalary(){
		this.totalSalary=this.getBasicSalary();
	}

	public String toString() {
		return "Employee [employeeId=" + employeeId + ", firstName=" + firstName
				+ ", lastname=" + lastname + ", basicSalary=" + basicSalary
				+ ", totalSalary=" + totalSalary + "]";
	}
}
