package com.cg.inheritancedemo;

public class MainClass {

	public static void main(String[] args) {
		Employee emp;
		emp=new PEmployee(102, "Anmol", "Kaur", 1000);
		emp.calculateTotalSalary();
		System.out.println(emp.getTotalSalary());
		System.out.println(emp);
		emp=new CEmployee(103,"Jashlin","Kaur",2000);
		CEmployee cemp=(CEmployee) emp;
		cemp.signContract();
		emp.calculateTotalSalary();
		System.out.println(emp);
		
	}
}
