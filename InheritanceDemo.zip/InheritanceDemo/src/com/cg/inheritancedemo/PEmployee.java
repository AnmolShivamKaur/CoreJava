package com.cg.inheritancedemo;

public class PEmployee extends Employee{
	private int hra,da,ta;

	public PEmployee() {
		super();
	}

	public PEmployee(int employeeId, String firstName, String lastname,
			int basicSalary) {
		super(employeeId, firstName, lastname, basicSalary);
	}

	public PEmployee(int hra, int da, int ta) {
		super();
		this.hra = hra;
		this.da = da;
		this.ta = ta;
	}

	public int getHra() {
		return hra;
	}

	public void setHra(int hra) {
		this.hra = hra;
	}

	public int getDa() {
		return da;
	}

	public void setDa(int da) {
		this.da = da;
	}

	public int getTa() {
		return ta;
	}

	public void setTa(int ta) {
		this.ta = ta;
	}
	public void calculateTotalSalary(){
		hra=(this.getBasicSalary()*10)/100;
		da=(this.getBasicSalary()*10)/100;
		ta=(this.getBasicSalary()*10)/100;
		this.setTotalSalary(this.getBasicSalary()+hra+ta+da);
	}
	public String toString() {
		return super.toString()+"hra=" + hra + ", da=" + da + ", ta=" + ta ;
	}

}
