package com.cg.mobilebilling.client;

import com.cg.mobilebilling.beans.*;

public class MainClass {

	public static void main(String[] args) {
		Bill bill1=new Bill(1, 25, 20, 40, 10, 100, 200, 1,5, 4, 100, 50, 40, 10);
		Bill bill2=new Bill(2, 35, 40, 10, 30, 200, 300, 2,5, 4, 200, 50, 40, 20);
		Bill bill3=new Bill(3, 45, 30, 20, 20, 300, 400, 3,5,4, 300, 50, 40, 10);
		Plan plan1=new Plan(1, 200, 100, 10, 100, 200, 100, 20, 2, 1, 1, 100);
		Plan plan2=new Plan(2, 300, 100, 10, 100, 200, 100, 20, 2, 2, 1, 300);
		Plan plan3=new Plan(3, 400, 100, 10, 100, 200, 100, 20, 2, 2, 1, 200);
		PostPaidAccount postpaidaccount1=new PostPaidAccount(666828016, 1, 1);
		PostPaidAccount postpaidaccount2=new PostPaidAccount(867896016, 2, 3);
		PostPaidAccount postpaidaccount3=new PostPaidAccount(616982801, 3, 2);
	}
}
