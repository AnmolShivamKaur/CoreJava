package com.cg.mobilebilling.beans;

public class Bill {
	private int billId, noOfLocalSMS, noOfStdSMS, noOfLocalCalls, noOfSTDCalls, internetDataUsageUnits, internetDatausageunitsamount,
	billMonth, stateGST, centralGST , totalBillAmount, localSMSAmount, stdSMSAmount, localCallAmount;
	public Bill() {
		super();
	}
	public Bill(int billId, int noOfLocalSMS, int noOfStdSMS,
			int noOfLocalCalls, int noOfSTDCalls, int internetDataUsageUnits,
			int internetDatausageunitsamount, int billMonth, int stateGST,
			int centralGST, int totalBillAmount, int localSMSAmount,
			int stdSMSAmount, int localCallAmount) {
		super();
		this.billId = billId;
		this.noOfLocalSMS = noOfLocalSMS;
		this.noOfStdSMS = noOfStdSMS;
		this.noOfLocalCalls = noOfLocalCalls;
		this.noOfSTDCalls = noOfSTDCalls;
		this.internetDataUsageUnits = internetDataUsageUnits;
		this.internetDatausageunitsamount = internetDatausageunitsamount;
		this.billMonth = billMonth;
		this.stateGST = stateGST;
		this.centralGST = centralGST;
		this.totalBillAmount = totalBillAmount;
		this.localSMSAmount = localSMSAmount;
		this.stdSMSAmount = stdSMSAmount;
		this.localCallAmount = localCallAmount;
	}
	public int getBillId() {
		return billId;
	}
	public void setBillId(int billId) {
		this.billId = billId;
	}
	public int getNoOfLocalSMS() {
		return noOfLocalSMS;
	}
	public void setNoOfLocalSMS(int noOfLocalSMS) {
		this.noOfLocalSMS = noOfLocalSMS;
	}
	public int getNoOfStdSMS() {
		return noOfStdSMS;
	}
	public void setNoOfStdSMS(int noOfStdSMS) {
		this.noOfStdSMS = noOfStdSMS;
	}
	public int getNoOfLocalCalls() {
		return noOfLocalCalls;
	}
	public void setNoOfLocalCalls(int noOfLocalCalls) {
		this.noOfLocalCalls = noOfLocalCalls;
	}
	public int getNoOfSTDCalls() {
		return noOfSTDCalls;
	}
	public void setNoOfSTDCalls(int noOfSTDCalls) {
		this.noOfSTDCalls = noOfSTDCalls;
	}
	public int getInternetDataUsageUnits() {
		return internetDataUsageUnits;
	}
	public void setInternetDataUsageUnits(int internetDataUsageUnits) {
		this.internetDataUsageUnits = internetDataUsageUnits;
	}
	public int getInternetDatausageunitsamount() {
		return internetDatausageunitsamount;
	}
	public void setInternetDatausageunitsamount(int internetDatausageunitsamount) {
		this.internetDatausageunitsamount = internetDatausageunitsamount;
	}
	public int getBillMonth() {
		return billMonth;
	}
	public void setBillMonth(int billMonth) {
		this.billMonth = billMonth;
	}
	public int getStateGST() {
		return stateGST;
	}
	public void setStateGST(int stateGST) {
		this.stateGST = stateGST;
	}
	public int getCentralGST() {
		return centralGST;
	}
	public void setCentralGST(int centralGST) {
		this.centralGST = centralGST;
	}
	public int getTotalBillAmount() {
		return totalBillAmount;
	}
	public void setTotalBillAmount(int totalBillAmount) {
		this.totalBillAmount = totalBillAmount;
	}
	public int getLocalSMSAmount() {
		return localSMSAmount;
	}
	public void setLocalSMSAmount(int localSMSAmount) {
		this.localSMSAmount = localSMSAmount;
	}
	public int getStdSMSAmount() {
		return stdSMSAmount;
	}
	public void setStdSMSAmount(int stdSMSAmount) {
		this.stdSMSAmount = stdSMSAmount;
	}
	public int getLocalCallAmount() {
		return localCallAmount;
	}
	public void setLocalCallAmount(int localCallAmount) {
		this.localCallAmount = localCallAmount;
	}
}
