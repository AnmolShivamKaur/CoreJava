package com.cg.mobilebilling.beans;

public class PostPaidAccount {
	private int mobileNo, customerId, PlanId;
	public PostPaidAccount() {
		super();
	}
	public PostPaidAccount(int mobileNo, int customerId, int planId) {
		super();
		this.mobileNo = mobileNo;
		this.customerId = customerId;
		PlanId = planId;
	}
	public int getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(int mobileNo) {
		this.mobileNo = mobileNo;
	}
	public int getCustomerId() {
		return customerId;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	public int getPlanId() {
		return PlanId;
	}
	public void setPlanId(int planId) {
		PlanId = planId;
	}
}
