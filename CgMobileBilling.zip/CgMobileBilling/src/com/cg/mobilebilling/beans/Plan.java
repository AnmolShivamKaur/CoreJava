package com.cg.mobilebilling.beans;

public class Plan {
	private int planId, monthlyrental, freelocalcalls , freeSTDCalls, freeLocalSMS, freeSTDSMS, freeInternetDatausageunits,
	localcallrates, STDCallRate, LocalSMSRate, STDSMSrate, InternetDatausagerate;
	public Plan() {
		super();
	}
	public Plan(int planId, int monthlyrental, int freelocalcalls,
			int freeSTDCalls, int freeLocalSMS, int freeSTDSMS,
			int freeInternetDatausageunits, int localcallrates,
			int sTDCallRate, int localSMSRate, int sTDSMSrate,
			int internetDatausagerate) {
		super();
		this.planId = planId;
		this.monthlyrental = monthlyrental;
		this.freelocalcalls = freelocalcalls;
		this.freeSTDCalls = freeSTDCalls;
		this.freeLocalSMS = freeLocalSMS;
		this.freeSTDSMS = freeSTDSMS;
		this.freeInternetDatausageunits = freeInternetDatausageunits;
		this.localcallrates = localcallrates;
		STDCallRate = sTDCallRate;
		LocalSMSRate = localSMSRate;
		STDSMSrate = sTDSMSrate;
		InternetDatausagerate = internetDatausagerate;
	}
	public int getPlanId() {
		return planId;
	}
	public void setPlanId(int planId) {
		this.planId = planId;
	}
	public int getMonthlyrental() {
		return monthlyrental;
	}
	public void setMonthlyrental(int monthlyrental) {
		this.monthlyrental = monthlyrental;
	}
	public int getFreelocalcalls() {
		return freelocalcalls;
	}
	public void setFreelocalcalls(int freelocalcalls) {
		this.freelocalcalls = freelocalcalls;
	}
	public int getFreeSTDCalls() {
		return freeSTDCalls;
	}
	public void setFreeSTDCalls(int freeSTDCalls) {
		this.freeSTDCalls = freeSTDCalls;
	}
	public int getFreeLocalSMS() {
		return freeLocalSMS;
	}
	public void setFreeLocalSMS(int freeLocalSMS) {
		this.freeLocalSMS = freeLocalSMS;
	}
	public int getFreeSTDSMS() {
		return freeSTDSMS;
	}
	public void setFreeSTDSMS(int freeSTDSMS) {
		this.freeSTDSMS = freeSTDSMS;
	}
	public int getFreeInternetDatausageunits() {
		return freeInternetDatausageunits;
	}
	public void setFreeInternetDatausageunits(int freeInternetDatausageunits) {
		this.freeInternetDatausageunits = freeInternetDatausageunits;
	}
	public int getLocalcallrates() {
		return localcallrates;
	}
	public void setLocalcallrates(int localcallrates) {
		this.localcallrates = localcallrates;
	}
	public int getSTDCallRate() {
		return STDCallRate;
	}
	public void setSTDCallRate(int sTDCallRate) {
		STDCallRate = sTDCallRate;
	}
	public int getLocalSMSRate() {
		return LocalSMSRate;
	}
	public void setLocalSMSRate(int localSMSRate) {
		LocalSMSRate = localSMSRate;
	}
	public int getSTDSMSrate() {
		return STDSMSrate;
	}
	public void setSTDSMSrate(int sTDSMSrate) {
		STDSMSrate = sTDSMSrate;
	}
	public int getInternetDatausagerate() {
		return InternetDatausagerate;
	}
	public void setInternetDatausagerate(int internetDatausagerate) {
		InternetDatausagerate = internetDatausagerate;
	}
}
