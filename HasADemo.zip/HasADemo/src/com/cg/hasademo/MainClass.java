package com.cg.hasademo;

public class MainClass {

	public static void main(String[] args) {
		Address address=new Address("Dhanbad", "Jharkhand", "India", 28301);
		Customer customer=new Customer("Anmol", "Kaur", 101, address);
		
		/*Address address2=customer.getAddress();
		System.out.println(address2.getCity());*/
		
		System.out.println(customer.getAddress().getCity());
		
		/*customer.getAddress().setCountry("New country");
		customer.getAddress().setCity("New city");
		customer.getAddress().setState("New state");
		customer.getAddress().setPincode(834678);*/
		
		customer.setAddress(new Address("New country", "New city", "New country", 89644));
	}
}
