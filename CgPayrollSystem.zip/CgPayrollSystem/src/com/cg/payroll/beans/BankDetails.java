package com.cg.payroll.beans;

public class BankDetails {
	private int accountNo;
	private String bankname, ifsccode;
	public BankDetails() {
		super();
	}
	public BankDetails(int accountNo, String bankname, String ifsccode) {
		super();
		this.accountNo = accountNo;
		this.bankname = bankname;
		this.ifsccode = ifsccode;
	}
	public int getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(int accountNo) {
		this.accountNo = accountNo;
	}
	public String getBankname() {
		return bankname;
	}
	public void setBankname(String bankname) {
		this.bankname = bankname;
	}
	public String getIfsccode() {
		return ifsccode;
	}
	public void setIfsccode(String ifsccode) {
		this.ifsccode = ifsccode;
	}
}
