package com.cg.payroll.beans;

public class Associate {
	private int associateId, yearlyinv;
	private String firstName,lastName,dept,designation,pancardNo,emailid;
	private BankDetails bankDetails;
	private Salary salary;
	
	public Associate() {
		super();
	}
	
	public Associate(int associateId, int yearlyinv, String firstName,
			String lastName, String dept, String designation, String pancardNo,
			String emailid) {
		super();
		this.associateId = associateId;
		this.yearlyinv = yearlyinv;
		this.firstName = firstName;
		this.lastName = lastName;
		this.dept = dept;
		this.designation = designation;
		this.pancardNo = pancardNo;
		this.emailid = emailid;
	}
	
	
	public Associate(int associateId, int yearlyinv, String firstName,
			String lastName, String dept, String designation, String pancardNo,
			String emailid, BankDetails bankDetails, Salary salary) {
		super();
		this.associateId = associateId;
		this.yearlyinv = yearlyinv;
		this.firstName = firstName;
		this.lastName = lastName;
		this.dept = dept;
		this.designation = designation;
		this.pancardNo = pancardNo;
		this.emailid = emailid;
		this.bankDetails = bankDetails;
		this.salary = salary;
	}
	public Associate(int yearlyinv, String firstName, String lastName,
			String dept, String designation, String pancardNo, String emailid,
			BankDetails bankDetails, Salary salary) {
		super();
		this.yearlyinv = yearlyinv;
		this.firstName = firstName;
		this.lastName = lastName;
		this.dept = dept;
		this.designation = designation;
		this.pancardNo = pancardNo;
		this.emailid = emailid;
		this.bankDetails = bankDetails;
		this.salary = salary;
	}

	public int getAssociateId() {
		return associateId;
	}
	public void setAssociateId(int associateId) {
		this.associateId = associateId;
	}
	public int getYearlyinv() {
		return yearlyinv;
	}
	public void setYearlyinv(int yearlyinv) {
		this.yearlyinv = yearlyinv;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getDept() {
		return dept;
	}
	public void setDept(String dept) {
		this.dept = dept;
	}
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	public String getPancardNo() {
		return pancardNo;
	}
	public void setPancardNo(String pancardNo) {
		this.pancardNo = pancardNo;
	}
	public String getEmailid() {
		return emailid;
	}
	public void setEmailid(String emailid) {
		this.emailid = emailid;
	}
	public BankDetails getBankDetails() {
		return bankDetails;
	}
	public void setBankDetails(BankDetails bankDetails) {
		this.bankDetails = bankDetails;
	}
	public Salary getSalary() {
		return salary;
	}
	public void setSalary(Salary salary) {
		this.salary = salary;	
	}

	@Override
	public String toString() {
		return "Associate [associateId=" + associateId + ", yearlyinv="
				+ yearlyinv + ", firstName=" + firstName + ", lastName="
				+ lastName + ", dept=" + dept + ", designation=" + designation
				+ ", pancardNo=" + pancardNo + ", emailid=" + emailid
				+ ", bankDetails=" + bankDetails + ", salary=" + salary + "]";
	}
	
}
