package com.cg.payroll.beans;

public class Salary {
	private int basic,hra,callow,pallow,mtax,epf,cpf,gratuity,gross,net;
	public Salary() {
		super();
	}

	public Salary(int basic, int epf, int cpf) {
		super();
		this.basic = basic;
		this.epf = epf;
		this.cpf = cpf;
	}

	public Salary(int basic, int hra, int callow, int pallow, int mtax,
			int epf, int cpf,  int gross, int net) {
		super();
		this.basic = basic;
		this.hra = hra;
		this.callow = callow;
		this.pallow = pallow;
		this.mtax = mtax;
		this.epf = epf;
		this.cpf = cpf;
		this.gross = gross;
		this.net = net;
	}
	public int getBasic() {
		return basic;
	}
	public void setBasic(int basic) {
		this.basic = basic;
	}
	public int getHra() {
		return hra;
	}
	public void setHra(int hra) {
		this.hra = hra;
	}
	public int getCallow() {
		return callow;
	}
	public void setCallow(int callow) {
		this.callow = callow;
	}
	public int getPallow() {
		return pallow;
	}
	public void setPallow(int pallow) {
		this.pallow = pallow;
	}
	public int getMtax() {
		return mtax;
	}
	public void setMtax(int mtax) {
		this.mtax = mtax;
	}
	public int getEpf() {
		return epf;
	}
	public void setEpf(int epf) {
		this.epf = epf;
	}
	public int getCpf() {
		return cpf;
	}
	public void setCpf(int cpf) {
		this.cpf = cpf;
	}
	public int getGratuity() {
		return gratuity;
	}
	public int getGross() {
		return gross;
	}
	public void setGross(int gross) {
		this.gross = gross;
	}
	public int getNet() {
		return net;
	}
	public void setNet(int net) {
		this.net = getGross()-getMtax();
	}
}
