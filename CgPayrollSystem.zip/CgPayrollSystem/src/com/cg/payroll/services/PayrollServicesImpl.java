package com.cg.payroll.services;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.exceptions.AssociateDetailsNotFoundException;
import com.cg.payroll.exceptions.PayrollServicesDownException;
import com.cg.payroll.dao.*;
public class PayrollServicesImpl implements PayrollServices{
	private AssociateDAO associateDAO = new AssociateDAOImpl() ;
	@Override
	public int acceptAssociateDetails(String firstName, String lastName,
			String emailId, String department, String designation,
			String pancard, int yearlyinv, int basic,
			int epf, int cpf, int accountNo, String bankname,
			String ifsccode) throws PayrollServicesDownException {
		Associate associate = new Associate(yearlyinv, firstName, lastName, department, designation, pancard, emailId, 
				new BankDetails(accountNo, bankname, ifsccode), 
				new Salary(basic, epf, cpf)); 
		associate=associateDAO.save(associate);
		return associate.getAssociateId();
	}
	@Override
	public int calculateNetSalary(int associateId)
			throws AssociateDetailsNotFoundException, PayrollServicesDownException {
		Associate associate =getAssociateDetails(associateId);
		associate.getSalary().setHra((30*associate.getSalary().getBasic())/100);
		associate.getSalary().setCallow((10*associate.getSalary().getBasic())/100);
		associate.getSalary().setPallow((25*associate.getSalary().getBasic())/100);
		associate.getSalary().setGross((associate.getSalary().getBasic()+associate.getSalary().getHra()+associate.getSalary().getCallow()+associate.getSalary().getPallow())*12);
		if(associate.getSalary().getBasic()>0 && associate.getSalary().getBasic()<250000)
			associate.getSalary().setMtax(0);
		else if(associate.getSalary().getBasic()>=250000 && associate.getSalary().getBasic()<500000)
			associate.getSalary().setMtax((associate.getSalary().getGross()-250000)*5/12*100);
		else if(associate.getSalary().getBasic()>=500000 && associate.getSalary().getBasic()<1000000)
			associate.getSalary().setMtax(((250000*5)/100*12)+((associate.getSalary().getBasic()-50000)*20)/100*12);
		else
			associate.getSalary().setMtax(((250000*5)/100*12)+(((50000)*20)/100*12)+((associate.getSalary().getBasic()-100000)*30)/100*12);
		associate.getSalary().setNet(associate.getSalary().getGross()-associate.getSalary().getMtax());
		return associate.getSalary().getNet();
	}

	@Override
	public Associate getAssociateDetails(int associateId)
			throws AssociateDetailsNotFoundException,
			PayrollServicesDownException {
		Associate associate = associateDAO.findOne(associateId);
		if(associate==null) throw new AssociateDetailsNotFoundException("Associate Details Not Found");

		return associate;
	}

	@Override
	public Associate[] getAllAssociatesDetails()
			throws PayrollServicesDownException {

		return null;
	}

}
