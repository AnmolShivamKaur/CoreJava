package com.cg.payroll.dao;

import java.util.ArrayList;
import java.util.HashMap;

import com.cg.payroll.beans.Associate;

public class AssociateDAOImpl implements AssociateDAO {
	private static  HashMap<Integer, Associate>  associates = new HashMap<>();
	private static int ASSOCIATE_ID_COUNTER=101;

	public Associate save(Associate associate) {
		associate.setAssociateId(ASSOCIATE_ID_COUNTER++);
		associates.put(associate.getAssociateId(),associate);
		return associate;
	}
	@Override
	public Associate findOne(int associateId) {
		return associates.get(associateId);
	}
	@Override
	public ArrayList<Associate> findAll() {	
		return new ArrayList<>(associates.values());
	}

}
