package com.cg.payroll.client;

import com.cg.payroll.beans.*;
import com.cg.payroll.exceptions.AssociateDetailsNotFoundException;
import com.cg.payroll.exceptions.PayrollServicesDownException;
import com.cg.payroll.services.*;

public class MainClass {

	public static void main(String[] args) throws AssociateDetailsNotFoundException,PayrollServicesDownException{
		int num=100;
		
		/*Associate associate2=new Associate(2, 12000, "Jashlin", "Kaur", "DEF", "Sr.Analyst", "Def234", "jashlin@gmail.com");
		Associate associate3=new Associate(3, 15000, "Jaspreet", "Kaur", "EFG", "Sr.Analyst", "Def234", "jaspreet@gmail.com");*
		BankDetails bankdetails1=new BankDetails(101, "HDFC", "HDFC0006");
		BankDetails bankdetails2=new BankDetails(102, "ICICI", "IC006");
		BankDetails bankdetails3=new BankDetails(103, "HSBC", "HC0006");
		Salary salary1=new Salary(1000, 800, 500, 300, 400, 300, 600, 100, 2000);
		Salary salary2=new Salary(2000, 900, 600, 400, 500, 400, 700, 300, 3000, 3500);
		Salary salary3=new Salary(3000, 1000, 800, 200, 700, 200, 100, 800, 4000, 4500);
		Associate associate1=new Associate(1, 10000, "Anmol", "Kaur", "ABC", "Sr.Analyst", "Abc123", "anmol@gmail.com",bankdetails1,salary1);
		associate1.getSalary().setHra((30*associate1.getSalary().getBasic())/100);
		associate2.getSalary().setHra((30*associate1.getSalary().getBasic())/100);
		associate3.getSalary().setHra((30*associate1.getSalary().getBasic())/100);
		associate1.getSalary().setCallow((10*associate1.getSalary().getBasic())/100);
		associate2.getSalary().setCallow((10*associate1.getSalary().getBasic())/100);
		associate3.getSalary().setCallow((10*associate1.getSalary().getBasic())/100);
		associate1.getSalary().setPallow((25*associate1.getSalary().getBasic())/100);
		associate2.getSalary().setPallow((25*associate1.getSalary().getBasic())/100);
		associate3.getSalary().setPallow((25*associate1.getSalary().getBasic())/100);
		associate1.getSalary().setGross(associate1.getSalary().getBasic()+associate1.getSalary().getHra()+associate1.getSalary().getCallow()+associate1.getSalary().getPallow());
		associate2.getSalary().setGross(associate2.getSalary().getBasic()+associate2.getSalary().getHra()+associate2.getSalary().getCallow()+associate2.getSalary().getPallow());
		associate3.getSalary().setGross(associate3.getSalary().getBasic()+associate3.getSalary().getHra()+associate3.getSalary().getCallow()+associate3.getSalary().getPallow());
		associate1.getSalary().setMtax((5*associate1.getSalary().getGross()*12)/12*100);
	associate2.getSalary().setMtax((5*associate2.getSalary().getGross()*12)/12*100);
		associate3.getSalary().setMtax((5*associate3.getSalary().getGross()*12)/12*100);*/
		Associate associate1 = new Associate(101, 15000, "Satish", "Mahajan", "Sr. Con", "YTP", "JDDU2664F", "satish@gmail.com", new BankDetails(96853256, "ICICI", "ICIC000562"), new Salary(40000,  1000, 2000));
		Associate associate2 = new Associate(102, 20000, "Rajesh", "Kumar", "Sr. Con", "YTP", "UDHG5865D", "rajesh@gmail.com", new BankDetails(85694523, "HDFC", "HDFC000252"), new Salary(35000,  800, 1500));
		Associate associate3 = new Associate(103, 25000, "Ankit", "Kumar", "Sr. Con", "YTP", "SYTRE8965S", "ankit@gmail.com", new BankDetails(96874586, "ICICI", "ICIC000562"), new Salary(50000, 1500,  2500));
		
		Associate[] associate = new Associate[3];
		associate[0] = new Associate(101, 15000, "Satish", "Mahajan", "Sr. Con", "YTP", "JDDU2664F", "satish@gmail.com", new BankDetails(96853256, "ICICI", "ICIC000562"), new Salary(40000, 1000,  2000));
		associate[1] = new Associate(102, 20000, "Rajesh", "Kumar", "Sr. Con", "YTP", "UDHG5865D", "rajesh@gmail.com", new BankDetails(85694523, "HDFC", "HDFC000252"), new Salary(35000, 800, 1500));
		associate[2] = new Associate(103, 25000, "Ankit", "Kumar", "Sr. Con", "YTP", "SYTRE8965S", "ankit@gmail.com", new BankDetails(96874586, "ICICI", "ICIC000562"), new Salary(50000, 1500, 2500));
		System.out.println(associate1.getSalary().getGross());
		
		PayrollServices payrollServices = new PayrollServicesImpl();
		payrollServices.acceptAssociateDetails("Anmol", "Kaur", "anmol@gmailcom", "XYZ", "Sr.Con.", "EWQ1234",1000, 2000, 300, 500, 6789, "HDFC", "HDFC009");
		System.out.println(payrollServices.calculateNetSalary(101));
	}
}
