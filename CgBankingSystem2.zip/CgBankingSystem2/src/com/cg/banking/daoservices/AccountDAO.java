package com.cg.banking.daoservices;

import java.sql.SQLException;
import java.util.ArrayList;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Transaction;

public interface AccountDAO {
	Account saveAccountDetails(Account account) throws SQLException;
	Account getAccountDetails(long accountNo) throws SQLException;
	int updateTransaction(long accountNo,float amount,String transactionType);
	ArrayList<Transaction> getAccountAllTransactionDetails(long accountNumber);
	ArrayList<Account> getAllAccountDetails();
	String getAccountStatus(long accountNo);

}