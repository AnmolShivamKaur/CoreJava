package com.capgemini.bank.service;

import com.capgemini.bank.bean.DemandDraft;
import com.capgemini.bank.exceptions.DemandDraftServicesDownException;
import com.capgemini.bank.exceptions.InvalidDDAmountException;
import com.capgemini.bank.exceptions.InvalidTransactionIdException;

public interface IDemandDraftService {
	
}
