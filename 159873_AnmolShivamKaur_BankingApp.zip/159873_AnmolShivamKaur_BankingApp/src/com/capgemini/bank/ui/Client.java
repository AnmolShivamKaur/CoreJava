package com.capgemini.bank.ui;

import java.sql.SQLException;
import java.util.Scanner;

import com.capgemini.bank.exceptions.DemandDraftServicesDownException;
import com.capgemini.bank.exceptions.InvalidDDAmountException;
import com.capgemini.bank.exceptions.InvalidTransactionIdException;
import com.capgemini.bank.service.DemandDraftService;

public class Client {

	public static void main(String[] args) {

	}
}
