package com.capgemini.bank.dao;

import java.sql.SQLException;

import com.capgemini.bank.bean.DemandDraft;

public interface IDemandDraftDAO {

}
