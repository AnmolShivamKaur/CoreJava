package com.capgemini.bank.exceptions;

public class DemandDraftServicesDownException extends Exception{

	public DemandDraftServicesDownException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public DemandDraftServicesDownException(String message, Throwable cause,
			boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public DemandDraftServicesDownException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public DemandDraftServicesDownException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public DemandDraftServicesDownException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

}
