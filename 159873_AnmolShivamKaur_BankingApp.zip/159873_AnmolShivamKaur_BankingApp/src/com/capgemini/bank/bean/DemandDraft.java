package com.capgemini.bank.bean;

public class DemandDraft {
	private String customerName, inFavorOf, demandDraftDescription,phoneNumber,dateOfTransaction;
	private double demandDraftAmount,demandDraftCommission;
	private int transactionId;
	
}
