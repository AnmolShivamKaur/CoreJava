package com.cg.project.fileclass;

import java.io.File;
import java.io.IOException;

public class MainClass {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		IOClassesDemo io=new IOClassesDemo();
		io.fileClassDemo();
		File fileFrom=new File("D:\\CG\\pit");
		File fileTo=new File("");
		io.byteStreamReadWrite(fileFrom,fileTo);
	}

}
