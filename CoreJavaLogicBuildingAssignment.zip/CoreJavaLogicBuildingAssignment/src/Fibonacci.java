
public class Fibonacci {

	public static void main(String []str){
		int n1=0,n2=1,n3,n=10; 
		System.out.println(n1+"\n"+n2);	
		for(int i=2;i<n;++i){    
			n3=n1+n2;    
			System.out.println(n3);    
			n1=n2;    
			n2=n3;    
		} 
	}
}
