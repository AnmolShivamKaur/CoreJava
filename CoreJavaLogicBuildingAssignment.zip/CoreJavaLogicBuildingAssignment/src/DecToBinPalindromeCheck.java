
public class DecToBinPalindromeCheck {

	public static void main(String[] args) {
		String binary="";
		int decimal=15,copy=decimal;
		while (decimal > 0){ 
			binary=binary+""+decimal%2; 
			decimal=decimal/2; 
		}
		int deciNum=Integer.parseInt(binary);
		System.out.println("Binary of  "+copy+" is "+deciNum);
		int n1=deciNum,r,rev=0;
		while(n1!=0){
			r=n1%10;
			rev=rev*10 +r;
			n1/=10;
		}
		if(rev==deciNum)
			System.out.println("Binary of  "+copy+" is palindrome");
		else
			System.out.println("Binary of  "+copy+" is not palindrome");
	} 
}


