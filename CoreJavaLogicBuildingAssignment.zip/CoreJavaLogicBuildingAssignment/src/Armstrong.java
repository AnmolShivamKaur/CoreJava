
public class Armstrong {

	public static void main(String []str){
		int n=153,n1=n,r,result=0;
		while (n1!=0){
			r=n1%10;
			result+= r*r*r;
			n1/=10;
		}
		if(result==n)
			System.out.println("Number "+n+" is Armstrong");
		else
			System.out.println("Number "+n+" is not Armstrong");
	}
}