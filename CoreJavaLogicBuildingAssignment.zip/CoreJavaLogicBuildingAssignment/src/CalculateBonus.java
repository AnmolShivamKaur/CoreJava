
public class CalculateBonus {

	public static void main(String[] args) {
		 String designation = "Sr.Con";
		 double experience=6,bonus,basicSalary=10000;
	        switch(designation) 
	        { 
	            case "Sr.Con": 
	                if(experience<3)
	                	bonus=0.1*basicSalary;
	                else if(experience>=3 && experience<=5)
	                	bonus=0.2*basicSalary;
	                else
	                	bonus=0.5*basicSalary;
	                System.out.println("Bonus for "+designation+" with "+experience+" years experience is "+bonus);
	                break; 
	            case "Sr.Analyst": 
	            	 if(experience<3)
	            		 bonus=0.2*basicSalary;
		             else if(experience>=3 && experience<=5)
		            	 bonus=0.3*basicSalary;
		             else
		              	bonus=0.7*basicSalary;
	            	 System.out.println("Bonus for "+designation+" with "+experience+" years is "+bonus);
	                break; 
	            case "Sr.Asso.": 
	            	 if(experience<3)
	            		 bonus=0.1*basicSalary;
		             else if(experience>=3 && experience<=5)
		            	 bonus=0.3*basicSalary;
		             else
		              	bonus=0.8*basicSalary;
	            	 System.out.println("Bonus for "+designation+" with "+experience+" years is "+bonus);
	                break; 
	            default: 
	                System.out.println("No Bonus"); 
	        } 
	}
}
