
public class MatrixMultiplication {

	public static void main(String[] args) {
		int mat1[][] = {{1,1,1}, 
				{2,2,2}, 
				{3,3,3}}; 

		int mat2[][] = {{1, 1,1}, 
				{2,2,2}, 
				{3,3,3}};
		int N=3;
		int res[][]=new int[N][N] ;
		for (int i=0; i<N; i++) { 
			for (int j=0; j<N; j++) { 
				res[i][j]=0; 
				for (int k=0; k<N; k++) 
					res[i][j] += mat1[i][k]*mat2[k][j]; 
			} 
		} 
		for (int i=0; i<N; i++) 
        { 
            for (int j=0; j<N; j++) 
                System.out.print( res[i][j] + " "); 
            	System.out.println(); 
        } 
	} 
}

