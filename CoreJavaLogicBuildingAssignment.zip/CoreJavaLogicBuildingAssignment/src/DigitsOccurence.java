import java.util.Arrays;
public class DigitsOccurence {

	public static void main(String[] args) {
		int numArr[]={2,1,3,4,5,1,5,8,9,2};
		int count;
		Arrays.sort(numArr);
		for(int i=0;i<numArr.length;i++){
			count=1;
			for(int j=i+1;j<numArr.length;j++){
					if(numArr[i]==numArr[j]){
							count=count+1;
					}
				}
			if(count!=0){
				System.out.print(numArr[i]+" occurs "+count+" times\n");
				i=i+count;
			}
		}
	}
}
