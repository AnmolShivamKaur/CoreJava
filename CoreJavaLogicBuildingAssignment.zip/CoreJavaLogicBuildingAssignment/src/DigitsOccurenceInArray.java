import java.util.*;
public class DigitsOccurenceInArray {

	public static void main(String[] args) {
		int count;
		int array[]={7,1,2,3,9,5,7,9,4,3,2};
		int num=array.length;
		Arrays.sort(array);
		System.out.println("Count of elements");
		for(int i=0;i<num;i++){
				count=1;
				for(int j=i+1;j<num;j++){
						if(array[i]==array[j]){
								count=count+1;
						}
					}
						if(count!=1){
							System.out.print(array[i]+" occurs "+count+" time\n");
							i=i+count;
						}
			}
	}
}
