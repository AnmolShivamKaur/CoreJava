
public class ThirdLargest {

	public static void main(String[] args) {
		int numArr[]={1,5,6,3,2,4};
		int l=numArr.length;
		int temp;
		for(int i=0;i<l;i++){
			for (int j=i+1; j< l; j++){
				if (numArr[i] > numArr[j]){  
					temp = numArr[i];  
					numArr[i] = numArr[j];  
					numArr[j] = temp;  
				}  
			}
		}
		System.out.println("Third Largest: "+numArr[l-3]);
	}		
}
