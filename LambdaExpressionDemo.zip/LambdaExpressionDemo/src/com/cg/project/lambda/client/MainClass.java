package com.cg.project.lambda.client;

import com.cg.project.lambda.beans.FunctionalInterface1;
import com.cg.project.lambda.beans.FunctionalInterface2;

public class MainClass {

	public static void main(String[] args) {
		FunctionalInterface1 ref1=() ->System.out.println("Hello World");
		ref1.greetUser();
		FunctionalInterface2 ref2=(a,b) ->a+b;
		System.out.println(ref2.add(100, 200));
	}
}
