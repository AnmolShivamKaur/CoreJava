package com.cg.project.lambda.beans;
@FunctionalInterface
public interface FunctionalInterface2 {
	public int add(int a,int b);
}
