package com.cg.project.lambda.beans;
@FunctionalInterface
public interface FunctionalInterface1 {
	void greetUser();
}
