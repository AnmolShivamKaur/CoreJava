package com.capgemini.contactbook.dao;

import java.sql.SQLException;

import com.capgemini.contactbook.bean.EnquiryBean;
import com.capgemini.contactbook.exceptions.ContactBookException;

public interface ContactBookDao {
	public int addenquiry(EnquiryBean enqry)throws SQLException,ContactBookException;
	public EnquiryBean getEnquiryDetails(int EnquiryID)throws SQLException,ContactBookException;
}
