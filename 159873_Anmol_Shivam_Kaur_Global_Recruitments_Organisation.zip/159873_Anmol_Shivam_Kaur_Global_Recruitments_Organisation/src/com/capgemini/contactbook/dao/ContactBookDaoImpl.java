package com.capgemini.contactbook.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;

import com.capgemini.contactbook.bean.EnquiryBean;
import com.capgemini.contactbook.exceptions.ContactBookException;
import com.capgemini.contactbook.util.ConnectionProvider;

public class ContactBookDaoImpl implements ContactBookDao{
Connection conn=ConnectionProvider.getDBConnection();
Logger logger = Logger.getLogger(ContactBookDaoImpl.class);
	@Override
	public int addenquiry(EnquiryBean enqry) throws SQLException,
			ContactBookException {
		try{
		conn.setAutoCommit(false);
		PreparedStatement pstmt1=conn.prepareStatement("INSERT INTO ENQUIRY VALUES(ENQUIRIES.NEXTVAL,?,?,?,?,?)");
		pstmt1.setString(1,enqry.getfName());
		pstmt1.setString(2,enqry.getlName());
		pstmt1.setString(3,enqry.getContactNo());
		pstmt1.setString(4,enqry.getpDomain());
		pstmt1.setString(5,enqry.getpLocation());
		pstmt1.executeUpdate();
		conn.commit();
		PreparedStatement pstmt2=conn.prepareStatement("SELECT MAX(ENQRYID) FROM ENQUIRY");
		ResultSet rs=pstmt2.executeQuery();
		rs.next();
		int enqryId=rs.getInt(1);
		conn.setAutoCommit(true);
		logger.info("Details added with id "+enqryId);
			return enqryId;
		}
		catch (SQLException e) {
			e.printStackTrace();
			logger.error(e.getMessage()+" "+ e.getErrorCode());
			conn.rollback();
			throw e;
		} 
		finally { 
			conn.setAutoCommit(true); 
		}
	}
	@Override
	public EnquiryBean getEnquiryDetails(int EnquiryID)
			throws ContactBookException, SQLException {
		PreparedStatement pstmt1=conn.prepareStatement("SELECT * FROM ENQUIRY WHERE ENQRYID="+EnquiryID);
		ResultSet enquiryRS = pstmt1.executeQuery();
		if(enquiryRS.next()){
			int enqryId=enquiryRS.getInt("enqryId");
			String fName=enquiryRS.getString("firstName");
			String lName=enquiryRS.getString("lastName");
			String contactNo=enquiryRS.getString("contactNo");
			String pDomain=enquiryRS.getString("domain");
			String pLocation=enquiryRS.getString("city");
			EnquiryBean enquiryBean=new EnquiryBean(enqryId, fName, lName, contactNo, pLocation, pDomain);
			return enquiryBean;
		}
		return null;
	}

}
