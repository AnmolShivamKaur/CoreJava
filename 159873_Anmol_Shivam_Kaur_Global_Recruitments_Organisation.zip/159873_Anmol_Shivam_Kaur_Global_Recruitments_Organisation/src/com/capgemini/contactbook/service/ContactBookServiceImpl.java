package com.capgemini.contactbook.service;

import java.sql.SQLException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import com.capgemini.contactbook.bean.EnquiryBean;
import com.capgemini.contactbook.dao.ContactBookDao;
import com.capgemini.contactbook.dao.ContactBookDaoImpl;
import com.capgemini.contactbook.exceptions.ContactBookException;

public class ContactBookServiceImpl implements ContactBookService{
ContactBookDao contactBookDao=new ContactBookDaoImpl();
	@Override
	public int addEnquiry(EnquiryBean enqry) throws ContactBookException {
		try{
			 enqry.setEnqryId(contactBookDao.addenquiry(enqry));
		} 
		catch (SQLException e) {
			e.printStackTrace();
		}
		return enqry.getEnqryId();
	}

	@Override
	public EnquiryBean getEnquiryDetails(int EnquiryID)
			throws ContactBookException {
			EnquiryBean enquiry = null;
			try{
				enquiry = contactBookDao.getEnquiryDetails(EnquiryID);
			} catch (SQLException e) {
				e.printStackTrace();
			}
			if (enquiry == null){
			return null;
			}
			else
			return enquiry;
	}

	@Override
	public boolean isValidEnquiry(EnquiryBean enqry)
			throws ContactBookException {
		if(validateContactNo(enqry.getContactNo())==true&&validateFirstName(enqry.getfName())==true&&
				validateLastName(enqry.getlName())==true&&validateDomain(enqry.getpDomain())==true&&validateLocation(enqry.getpLocation())==true)
			return true;
		else if(validateContactNo(enqry.getContactNo())==false)
		System.out.println("Enter valid contact number");
		else if(validateFirstName(enqry.getfName())==false)
			System.out.println("Enter valid first name");
		else if(validateLastName(enqry.getlName())==false)
			System.out.println("Enter valid last name");
		else if(validateDomain(enqry.getpDomain())==false)
			System.out.println("Enter valid domain name");
		else if(validateLocation(enqry.getpLocation())==false)
			System.out.println("Enter valid location");
		return false;
	}
	public boolean validateContactNo(String contactNo){
		Pattern pattern=Pattern.compile("\\d{10}");
		Matcher matcher=pattern.matcher(contactNo);
		if(matcher.matches())
		 return true;
		else
			return false;
	}
	public boolean validateFirstName(String fName){
		if(fName.length()>0)
		 return true;
		else
			return false;
	}
	public boolean validateLastName(String lName){
		if(lName.length()>0)
		 return true;
		else
			return false;
	}
	public boolean validateDomain(String pDomain){
		if(pDomain.length()>0)
		 return true;
		else
			return false;
	}
	public boolean validateLocation(String pLocation){
		if(pLocation.length()>0)
		 return true;
		else
			return false;
	}
}

