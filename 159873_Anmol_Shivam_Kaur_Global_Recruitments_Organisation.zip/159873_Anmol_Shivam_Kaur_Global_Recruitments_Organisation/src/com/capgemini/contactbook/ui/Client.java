package com.capgemini.contactbook.ui;

import java.sql.SQLException;
import java.util.Scanner;

import com.capgemini.contactbook.bean.EnquiryBean;
import com.capgemini.contactbook.exceptions.ContactBookException;
import com.capgemini.contactbook.service.ContactBookService;
import com.capgemini.contactbook.service.ContactBookServiceImpl;

public class Client {

	public static void main(String[] args) throws ContactBookException, SQLException {
		ContactBookService service=new ContactBookServiceImpl();
		System.out.println("************Global Recruitments*********");
		Scanner sc=new Scanner(System.in);
		System.out.println("Choose an operation\n1.Enter Enquiry Details\n2.View Enquiry Details on Id\n0.Exit");
		System.out.println("Please enter a choice:");
		int choice=sc.nextInt();
		try{
		switch(choice){
		case 1:
			System.out.println("Enter First Name:");
			String fName=sc.next();
			System.out.println("Enter Last Name:");
			String lName=sc.next();
			System.out.println("Enter Contact Number:");
			String contactNo=sc.next();
			System.out.println("Enter Preferred Domain:");
			String pDomain=sc.next();
			System.out.println("Enter Preferred Location:");
			String pLocation=sc.next();
			EnquiryBean enquiryBean=new EnquiryBean(fName, lName, contactNo, pLocation, pDomain);
			if(service.isValidEnquiry(enquiryBean)==true){
				service.addEnquiry(enquiryBean);
				System.out.println("Thank you "+fName+" "+lName+" your Unique Id is "+enquiryBean.getEnqryId()+" we will contact you shortly.");
			}
			break;
			case 2:
				System.out.println("Enter the Enquiry No. : ");
				int enquiryID=sc.nextInt();
				EnquiryBean enquiry2 = service.getEnquiryDetails(enquiryID);
				if(enquiry2!=null)
				System.out.println("Id\t\t First Name\t\t Last Name\t\t Contact No.\t\t Preffered Domain\t\t Preffered Location\n"+enquiry2.getEnqryId()+"\t\t "+enquiry2.getfName()+"\t\t "+enquiry2.getlName()+"\t\t \t"+enquiry2.getContactNo()+"\t\t "+enquiry2.getpDomain()+"\t\t "+enquiry2.getpLocation());
				else
					System.out.println("Sorry no details found");
				break;
			case 0:
				System.out.println("Please enter a choice ");
				break;
			default:
				System.out.println("Please enter a valid choice.");
				}
		}
		catch(ContactBookException e){
			System.err.println(e.getMessage());
		}
		System.out.println("\nThank you for selecting us!!");
	}
}
