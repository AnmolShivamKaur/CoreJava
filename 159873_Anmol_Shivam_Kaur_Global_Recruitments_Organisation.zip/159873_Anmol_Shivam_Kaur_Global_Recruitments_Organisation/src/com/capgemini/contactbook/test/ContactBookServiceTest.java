package com.capgemini.contactbook.test;
import static org.junit.Assert.assertTrue;

import java.sql.SQLException;

import com.capgemini.contactbook.bean.EnquiryBean;
import com.capgemini.contactbook.dao.ContactBookDao;
import com.capgemini.contactbook.exceptions.ContactBookException;
import com.capgemini.contactbook.service.ContactBookService;
import com.capgemini.contactbook.service.ContactBookServiceImpl;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;


public class ContactBookServiceTest {
     public static ContactBookDao contactBookDao ;
     public static ContactBookService contactBookService ;
     @BeforeClass
 	public static void setUpBeforeClass() throws SQLException{
     contactBookService = new ContactBookServiceImpl() ;
 	}
     @Test
 	public void testAddEnquiry() throws SQLException, ContactBookException {
    	
    	 	contactBookService= new ContactBookServiceImpl() ;
 		int n = contactBookService.addEnquiry( new EnquiryBean("Anmol", "Kaur", "8987898789","Dhanbad", "SeniorAnalyst"));
		assertTrue(n>1001);
     }
@AfterClass
public static void TearDownAfterClass(){
	contactBookService=null;
	
}
}
