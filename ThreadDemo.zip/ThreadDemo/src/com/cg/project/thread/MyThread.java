package com.cg.project.thread;

public class MyThread extends Thread {

	public MyThread(String name) {
		super(name);
	}
	public void run(){
	
		for(int i=1;i<=100;i++)	
			if(this.getName().equals("odd") && i%2!=0)
			System.out.println("Odd : "+i);
		
			else if(this.getName().equals("even")&&i%2==0)
				System.out.println("Even: "+i);	
	}
}
