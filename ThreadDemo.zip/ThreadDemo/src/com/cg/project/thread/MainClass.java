package com.cg.project.thread;

public class MainClass {

	public static void main(String[] args) {
		MyThread th1=new MyThread("odd");
		MyThread th2=new MyThread("even");
		th1.start();
		th2.start();
	}

}
