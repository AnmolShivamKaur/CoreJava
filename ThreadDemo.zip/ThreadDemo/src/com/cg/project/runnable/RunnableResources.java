package com.cg.project.runnable;

public class RunnableResources implements Runnable {
	
	public void run() {
		try{
		Thread t=Thread.currentThread();
		for(int i=1;i<=100;i++)	{
			if(t.getName().equals("odd") && i%2!=0){
			System.out.println("Odd : "+i);
			Thread.sleep(1000);
			}
	
			else if(t.getName().equals("even")&&i%2==0){
				System.out.println("Even: "+i);	
				Thread.sleep(1000);
			}
		} 
}
		catch(InterruptedException e){
			e.printStackTrace();
		}
	}
}
