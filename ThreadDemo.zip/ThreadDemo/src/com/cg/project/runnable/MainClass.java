package com.cg.project.runnable;

public class MainClass {

	public static void main(String[] args) {
		RunnableResources r1=new RunnableResources();
		Thread th1=new Thread(r1, "odd");
		Thread th2=new Thread(r1, "even");
		th1.start();
		th2.start();
		//lambda expression use to create runnable resource without creating a class
		Runnable r2= () ->{
			for(int i=1;i<10;i++)
				System.out.println("Tick "+i);
		};
	}
}
