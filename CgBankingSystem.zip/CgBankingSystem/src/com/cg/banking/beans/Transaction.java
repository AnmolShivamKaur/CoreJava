package com.cg.banking.beans;

public class Transaction {
	private int transactionId;
	private String timestamp,amount,transactiontype,transactionlocation,modeoftransaction,transactionstatus;
	public Transaction() {
		super();
	}
	public Transaction(int transactionId, String timestamp, String amount,
			String transactiontype, String transactionlocation,
			String modeoftransaction, String transactionstatus) {
		super();
		this.transactionId = transactionId;
		this.timestamp = timestamp;
		this.amount = amount;
		this.transactiontype = transactiontype;
		this.transactionlocation = transactionlocation;
		this.modeoftransaction = modeoftransaction;
		this.transactionstatus = transactionstatus;
	}
	public int getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(int transactionId) {
		this.transactionId = transactionId;
	}
	public String getTimestamp() {
		return timestamp;
	}
	public void setTimestamp(String timestamp) {
		this.timestamp = timestamp;
	}
	public String getAmount() {
		return amount;
	}
	public void setAmount(String amount) {
		this.amount = amount;
	}
	public String getTransactiontype() {
		return transactiontype;
	}
	public void setTransactiontype(String transactiontype) {
		this.transactiontype = transactiontype;
	}
	public String getTransactionlocation() {
		return transactionlocation;
	}
	public void setTransactionlocation(String transactionlocation) {
		this.transactionlocation = transactionlocation;
	}
	public String getModeoftransaction() {
		return modeoftransaction;
	}
	public void setModeoftransaction(String modeoftransaction) {
		this.modeoftransaction = modeoftransaction;
	}
	public String getTransactionstatus() {
		return transactionstatus;
	}
	public void setTransactionstatus(String transactionstatus) {
		this.transactionstatus = transactionstatus;
	}
}
