package com.cg.banking.client;

import com.cg.banking.beans.*;

public class MainClass {

	public static void main(String[] args) {
		Account account1=new Account(100, "10000", "Savings");
		Account account2=new Account(101, "20000", "Salary");
		Account account3=new Account(102, "30000", "Savings");
		Address address1=new Address("Dhanbad", "Jharkhand", "India", 828301);
		Address address2=new Address("Jamshedpur", "Jharkhand", "India", 828251);
		Address address3=new Address("Ludhiana", "Punjab", "India", 768251);
		Customer customer1=new Customer(1, "Anmol", "Kaur", "89867654", "anmol@gmail.com", "4018", "EWQP76", "06/05/2000");
		Customer customer2=new Customer(2, "Jashlin", "Kaur", "34867654", "jashlin@gmail.com", "4034", "QP706", "05/10/1998");
		Customer customer3=new Customer(3, "Anie", "Kaur", "34867654", "annie@gmail.com", "4015", "EWQP76", "06/05/1999");
		Transaction transaction1=new Transaction(1, "9:35", "10000", "Online", "Pune", "Online", "Failed");
		Transaction transaction2=new Transaction(2, "2:35", "20000", "Online", "Dhanbad", "Online", "Successful");
		Transaction transaction3=new Transaction(3, "1:35", "30000", "Online", "Jamshedpur", "Online", "Failed");
	}
}
