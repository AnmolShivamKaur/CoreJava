package com.cg.project.mathservices.client;

import com.cg.project.exceptions.InvalidNumberRangeException;
import com.cg.project.mathservices.MathServices;
import com.cg.project.mathservices.MathServicesImpl;

public class MainClass {

	public static void main(String[] args) {
		try{
		MathServices services=new MathServicesImpl();
		int x=(services.addNums(10,-2));
		System.out.println(x);
		System.out.println(services.multiNums(10, 20));
		}
		catch (InvalidNumberRangeException e){
		e.printStackTrace();
		}
		}
	}

