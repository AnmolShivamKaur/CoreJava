package com.cg.project.test;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.project.exceptions.InvalidNumberRangeException;
import com.cg.project.mathservices.MathServices;
import com.cg.project.mathservices.MathServicesImpl;

public class MathServicesTest {
	public static MathServices mathservices;
@BeforeClass
	public static void setUPTestEnv(){
		mathservices= new MathServicesImpl();
	}

@Before
public void setUpMockDataForTest(){
}

@Test(expected=InvalidNumberRangeException.class)
public void testAddNumbersForFirstNOInvalid() throws InvalidNumberRangeException{
	mathservices.addNums(-10, 20);
}

@Test(expected=InvalidNumberRangeException.class)
public void testAddNumbersForSecondNOInvalid() throws InvalidNumberRangeException{
	mathservices.addNums(10,-20);
}

@Test()
public void testAddNumbesrForBothValidNo() throws InvalidNumberRangeException {
	int expectedAns=30;
	int actualAns=	mathservices.addNums(10, 20);
	Assert.assertEquals(expectedAns, actualAns);
}

@Test(expected=InvalidNumberRangeException.class)
public void testSubtractNumbersForFirstNOInvalid() throws InvalidNumberRangeException{
	mathservices.subNums(-10, 20);
}

@Test(expected=InvalidNumberRangeException.class)
public void testSubtractNumbersForSecondNOInvalid() throws InvalidNumberRangeException{
	mathservices.subNums(10,-20);
}

@Test()
public void testSubtractNumbesrForBothValidNo() throws InvalidNumberRangeException {
	int expectedAns=10;
	int actualAns=	mathservices.subNums(20, 10);
	Assert.assertEquals(expectedAns, actualAns);
}

@Test(expected=InvalidNumberRangeException.class)
public void testMultiplyNumbersForFirstNOInvalid() throws InvalidNumberRangeException{
	mathservices.multiNums(-10, 20);
}

@Test(expected=InvalidNumberRangeException.class)
public void testMultiplyNumbersForSecondNOInvalid() throws InvalidNumberRangeException{
	mathservices.multiNums(10,-20);
}

@Test()
public void testMultiplyNumbesrForBothValidNo() throws InvalidNumberRangeException {
	int expectedAns=200;
	int actualAns=	mathservices.multiNums(10, 20);
	Assert.assertEquals(expectedAns, actualAns);
}
@After
public void tearDownMockDataForTest() {
	System.out.println("tearDownMockDataForTest()");
}


@AfterClass
public static void tearDownTestEnv() {
	mathservices=null;
}
}
