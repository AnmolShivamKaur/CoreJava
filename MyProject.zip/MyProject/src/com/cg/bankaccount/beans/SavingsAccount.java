package com.cg.bankaccount.beans;

import com.cg.bankaccount.exceptions.InvalidAgeException;

public class SavingsAccount extends Account{
	private final double minbalance=500;

	public SavingsAccount() {
		super();
	}
	
	public SavingsAccount(double balance, PersonDetails accountHolder) {
		super(balance, accountHolder);
		// TODO Auto-generated constructor stub
	}

	public SavingsAccount(long accountNumber, double balance,
			PersonDetails accountHolder) {
		super(accountNumber, balance, accountHolder);
	}
	@Override
	public void withdrawal(double amount) {
		if(super.getBalance()-amount>minbalance)
			super.setBalance(super.getBalance()-amount);
	}

	@Override
	public void deposit(double amount) {
			super.setBalance(super.getBalance()+amount);
	}
}
