package com.cg.bankaccount.beans;

import com.cg.bankaccount.exceptions.InvalidAgeException;

public class CurrentAccount extends Account {
	private static int overdraft_limit=20000;

	public CurrentAccount() {
		super();
	}
	
	public CurrentAccount(double balance, PersonDetails accountHolder) {
		super(balance, accountHolder);
		// TODO Auto-generated constructor stub
	}

	public CurrentAccount(long accountNumber, double balance,
			PersonDetails accountHolder) {
		super(accountNumber, balance, accountHolder);
	}
	@Override
	public void deposit(double amount) {
		if(amount<overdraft_limit)
			super.setBalance(super.getBalance()+amount);
	}

	@Override
	public void withdrawal(double amount) {
		if(super.getBalance()-amount>500)
			super.setBalance(super.getBalance()-amount);
		
	}
	
	

}
