package com.cg.bankaccount.beans;

import com.cg.bankaccount.exceptions.InvalidAgeException;

public abstract class Account {
	private long accountNumber;
	private static long accountNumber_counter=111111;
	private double balance;
	private PersonDetails accountHolder;
	public Account(long accountNumber, double balance,
			PersonDetails accountHolder) {
		super();
		this.accountNumber = accountNumber;
		this.balance = balance;
		this.accountHolder = accountHolder;
	}
	public Account accountnumber(Account account){
		account.setAccountNumber(accountNumber_counter++);
		return account;
	}
	public Account(double balance, PersonDetails accountHolder) {
		super();
		this.balance = balance;
		this.accountHolder = accountHolder;
	}

	public Account() {
		super();
	}
	public long getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(long accountNumber) {
		this.accountNumber = accountNumber;
	}
	public double getBalance(){
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	public PersonDetails getAccountHolder() {
		return accountHolder;
	}
	public void setAccountHolder(PersonDetails accounHolder) {
		this.accountHolder = accounHolder;
	}
	public abstract void deposit(double amount);
	public abstract void withdrawal(double amount);
	@Override
	public String toString() {
		return "accountNumber=" + accountNumber + ", balance="
				+ balance + ", accountHolder=" + accountHolder;
	}
	public void validateage(float age) throws InvalidAgeException{
		if(age<15) throw new InvalidAgeException("Age should be greater than 15");
	}

}
