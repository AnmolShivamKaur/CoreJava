package com.cg.bankaccount.client;
import com.cg.bankaccount.beans.Account;
import com.cg.bankaccount.beans.CurrentAccount;
import com.cg.bankaccount.beans.PersonDetails;
import com.cg.bankaccount.beans.SavingsAccount;
import com.cg.bankaccount.exceptions.InvalidAgeException;
public class MainClass {
	public static void main(String[] args) throws InvalidAgeException {
		Account account1=new SavingsAccount(2000, new PersonDetails("Smith", 28));
		account1.accountnumber(account1);
		account1.validateage(account1.getAccountHolder().getAge());
        account1.deposit(2000);		
		System.out.println(account1.getBalance());
		System.out.println(account1.toString());	
		Account account2=new CurrentAccount(3000, new PersonDetails("Kathy", 14));
		account2.accountnumber(account2);
		account2.validateage(account2.getAccountHolder().getAge());
		account2.withdrawal(2000);	
		System.out.println(account2.getBalance());
		System.out.println(account2.toString());		
	}
}
