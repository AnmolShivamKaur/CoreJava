package com.cg.eis.client;

import com.cg.eis.exception.EmployeeException;
import com.cg.eis.service.EmployeeserviceImpl;

public class MainClassEmployee {

	public static void main(String[] args) throws EmployeeException {
		EmployeeserviceImpl emp=new EmployeeserviceImpl();
		emp.getEmployeeDetails();
		emp.insuranceScheme();
		emp.displayEmployeeDetails();

	}

}
