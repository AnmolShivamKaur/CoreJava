package com.cg.eis.service;

import com.cg.eis.exception.EmployeeException;

public interface EmployeeService {
	public int insuranceScheme();
	public int getEmployeeDetails() throws EmployeeException;
	public int displayEmployeeDetails();
}
