package com.cg.eis.service;

import java.util.Scanner;

import com.cg.eis.bean.Employee;
import com.cg.eis.exception.EmployeeException;

public class EmployeeserviceImpl implements EmployeeService{
	Employee employee=new Employee();
	Scanner sc=new Scanner(System.in);

	@Override
	public int getEmployeeDetails() throws EmployeeException{
		employee.setId(sc.nextInt());
		employee.setDesignation(sc.next());
		employee.setName(sc.next());
		employee.setSalary(sc.nextInt());
		if(employee.getSalary()<3000) throw new EmployeeException("Salary should be greater than 3000");
		
		return 0;
	}

	@Override
	public int displayEmployeeDetails() {
		System.out.println(employee.getId()+
		employee.getDesignation()+
		employee.getName()+
		employee.getSalary()+employee.getInsuranceScheme());
		
		return 0;
	}

	@Override
	public int insuranceScheme() {
		if(employee.getSalary()>5000&&employee.getSalary()<20000)
			employee.setInsuranceScheme("Scheme C");
		else if(employee.getSalary()>=20000&&employee.getSalary()<40000)
			employee.setInsuranceScheme("Scheme B");
		else if(employee.getSalary()>=40000)
			employee.setInsuranceScheme("Scheme A");
		else
			employee.setInsuranceScheme("No Scheme");
		
		return 0;
	}

	
	}


