package com.cg.project.arraysandcollection;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class SortArrayList {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 ArrayList<String> products = new ArrayList<String>(); 
		 Scanner sc= new Scanner(System.in);
	        System.out.print("Enter number of products you want to enter:");
	        int count = sc.nextInt();
	        System.out.println("Enter all the names:");
	        for(int i = 0; i <= count; i++)
	        {
	          String a = sc.nextLine();
	          products.add(a);
	        }
	        Collections.sort(products); 
	  
	     for (String string : products) {
			System.out.println(string);
		}
	}

}
