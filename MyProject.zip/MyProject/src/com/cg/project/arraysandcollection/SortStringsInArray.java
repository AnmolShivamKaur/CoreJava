package com.cg.project.arraysandcollection;

import java.util.Scanner;

public class SortStringsInArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int count;
        String temp;
        Scanner sc= new Scanner(System.in);
        System.out.print("Enter number of products you want to enter:");
        count = sc.nextInt();
        String products[] = new String[count];
        System.out.println("Enter all the names:");
        for(int i = 0; i < count; i++)
        {
            products[i] = sc.nextLine();
        }
        for (int i = 0; i < count; i++) 
        {
            for (int j = i + 1; j < count; j++) 
            {
                if (products[i].compareTo(products[j])>0) 
                {
                    temp = products[i];
                    products[i] = products[j];
                    products[j] = temp;
                }
            }
        }
        System.out.print("Names in Sorted Order:");
        for (int i = 0; i < count - 1; i++) 
        {
            System.out.print(products[i] + ",");
        }
        System.out.print(products[count - 1]);
    }
}
