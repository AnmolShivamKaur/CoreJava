package com.cg.project.lab3;

import java.util.Scanner;

public class PositiveStringOrNot {
	public static boolean positiveString(char[]newString){
		char previous=' ' ;
		 for (char current : newString) {
		        if (current < previous)
		            return false;
		        previous = current;
		    }
		    return true;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter a string: ");
		String givenString=sc.nextLine();
		char[] newString = givenString.toCharArray();
		if(positiveString(newString)==true)
		System.out.println("String is positivc");
		else
		System.out.println("String is not positive");
	}

}
