package com.cg.project.lab3;

import java.util.Scanner;

public class StringModification {
		public static void stringModification(String givenString,int choice){
			switch (choice) {
			case 1:
				System.out.println(givenString+""+givenString);
				break;
			case 2:
				for (int i=0; i < givenString.length(); i++)
			        if (i % 2 != 0)
			          System.out.print("#");
			        else
			        	System.out.print(givenString.substring(i,i+1));
				break;
			case 3:
				 for (int i = 0; i < givenString.length(); i++) 
			            for (int j = 0; j < givenString.length(); j++) 
			                if (givenString.charAt(i) != givenString.charAt(j)) 
			                    System.out.print(givenString.charAt(i));
				 break;
			case 4:
				 for (int i = 0; i < givenString.length(); i++) {
					    char ch = givenString.charAt(i);
					    if (i % 2 == 0) 
					        System.out.print(ch);
					    else 
					        System.out.print(Character.toUpperCase(ch));
					}       
				 break;
			default:
				System.out.println("Choice entered is incorrect");
				break;
			}
		}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter a string: ");
		String givenString=sc.nextLine();
		System.out.println("Enter your choice:\n1.�	Add the String to itself\n2.�	Replace odd positions with #\n3.�	Remove duplicate characters in the String\n4.�	Change odd characters to upper case");
		int choice=sc.nextInt();
		stringModification(givenString, choice);
	}

}
