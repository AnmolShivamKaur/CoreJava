package com.cg.project.person;

public class PersonMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try{
		Person person1=new Person("Anmol", "Kaur",Gender.F ,432); 
		personDetails();	
		throw new EmptyNameInputException();
		}
		catch(EmptyNameInputException e){
			 System.out.println("Please do not enter spaces in the name.");
		}
	}
		public static void personDetails(){
			Person person2=new Person("", "",Gender.F,432); 
			String fullName=person2.getFullName();
			System.out.println("Person Details:\n_____________\n\n");
			System.out.println("First Name: "+person2.getFirstName()+"\nLast Name: "+person2.getLastName()+"\nGender: "+person2.getGender()+"\nPhone number: "+person2.getPhoneNumber());
		}

	}
