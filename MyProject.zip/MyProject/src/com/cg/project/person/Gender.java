package com.cg.project.person;

public enum Gender {
	    M,
	    F
}
