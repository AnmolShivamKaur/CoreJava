import java.util.Scanner;


public class CheckPositiveOrNegative {

	public static void main(String[] args) {
		System.out.println("Enter a number: ");
		Scanner sc=new Scanner(System.in);
		int number=sc.nextInt();
		if(number>0)
			System.out.println("Number is positive");
		else
			System.out.println("Number is negative");
	}

}
