package com.cg.assignment;

import java.util.Stack;
public class StackProblem{
    public int solution(String S){
        String[] stringParts=S.split("\\s");
        Stack<Integer> stack=new Stack<>();
        for (int i=0;i<stringParts.length;i++) {
            Integer in;
            switch (stringParts[i]){
                case "DUP":
                    if(stack.isEmpty()) return  -1 ;
                    stack.push(stack.peek());
                    break;
                case "POP":
                    if(stack.isEmpty()) return  -1 ;
                    stack.pop();
                    break;
                case "+":
                    if(stack.size() < 1) return -1 ;
                    in= 0;
                    in+=stack.pop();
                    in+=stack.pop();
                    stack.push(in);
                    break;
                case "-":
                    if(stack.size() < 1) return -1 ;
                    in=stack.pop();
                    in-=stack.pop();
                    stack.push(in);
                    break;
                default:
                    stack.push(Integer.parseInt(stringParts[i]));
                    break;
            }
        }
        if(stack.size() < 1) return -1 ;
        else return stack.peek();
    }
    public static void main(String []args)
    {
    	String given="13 DUP 4 POP 5 DUP + DUP + -"; 
    	StackProblem pro=new StackProblem();
    	int top=pro.solution(given);
    	System.out.println(top);
    }
}