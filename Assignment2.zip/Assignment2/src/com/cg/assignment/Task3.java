package com.cg.assignment;

public class Task3 {
	public static void main(String[] args) {
		int array[]={5,2,4,6,3,7};
		System.out.println(solution(array));

	}
	public static int solution(int[] array) {
		int min=1000000,i,j,temp=0;
		for(i=0;i<array.length;i++){
			for(j=i+2;j<array.length;j++){
				temp=array[i]+array[j];
				if(temp<min)
					min=temp;
			}
		}
		return min;
	}
}
