package com.cg.assignment;
import java.util.*;
public class Elevator {
	public static int solution(int a[], int b[],  int m, int x, int y)
	{
		int  currentPerson = 0;
				    int totalPersonCount = a.length;
				   double destinationFloors[]=new double[1000];
				   int totalWeightTwoPersons = 0;
				    int maxPersonCount = 0;
				   int totalTrips = 0;
				   int i=0;
				    boolean startElevator = false;
				    while (currentPerson < totalPersonCount){
				        if(maxPersonCount + 1 <= x && totalWeightTwoPersons + a[currentPerson] <= y){
				            destinationFloors[i]=b[currentPerson];
				            totalWeightTwoPersons += a[currentPerson];
				            }
				        else  if(currentPerson == totalPersonCount - 1){
				                startElevator =true;
				            maxPersonCount += 1;
				            currentPerson += 1;
				            }
				
				    else{
				            startElevator = true;
				            }
				        if (startElevator){
				            if(destinationFloors.length == 2 && destinationFloors[0] == destinationFloors[1]){
				                totalTrips += 1;
				            for(int j =0;i<destinationFloors.length;i++)
				                destinationFloors[j] = 0;
				            }
				            else{
				                totalTrips += destinationFloors.length;
				                for(int j =0;i<destinationFloors.length;i++)
					                destinationFloors[j] = 0;
				            startElevator = false;
				            maxPersonCount = 0;
				            totalWeightTwoPersons = 0;
				            }
				        }
				            if( destinationFloors.length == 0)
				                totalTrips += 1;}
				    return totalTrips;
	}
	public static void main(String[] args) {
		int a[]={40,40,100,80};
		int b[]={3,3,2,2};
		int x=2,m=5,y=150;
		int totalTrips=0;
		totalTrips=solution(a, b,m,x,y);
		System.out.println(totalTrips);
	
		}
	}
