package com.cg.assignment;

public class WholeSquaresInIntervals {
	public int wholeSquares(int a, int b){
		int count=0;
		        for (int i = a; i <= b; i++) 

		            for (int j = 1; j * j <= i; j++) 
		                if (j * j == i) 
		                    count++; 
		        return count; 
		    } 
	public static void main(String[] args) {
		int minRange=4,maxRange=20;
		WholeSquaresInIntervals whole=new WholeSquaresInIntervals();
		int x=whole.wholeSquares(minRange,maxRange);
		System.out.println(x);
	}
}
