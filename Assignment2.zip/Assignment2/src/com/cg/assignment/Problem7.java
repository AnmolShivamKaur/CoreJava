package com.cg.assignment;

public class Problem7 {
	public static int solution7(float[] arrayA,float[] arrayB){
		int i=0,count=0;
		float[] arrayC=new float[5];
		int n=arrayC.length;
		for(i=0;i<n;i++){
			arrayB[i]=arrayB[i]/100000;
			arrayC[i]=arrayA[i]+arrayB[i];
		}
		for(i=1;i<n;i++){
			for(int j=i;j<n;j++){
				float temp=arrayC[i]*arrayC[j];
				if(temp>=arrayC[i]+arrayC[j])
					count++;
			}
		}
		return count;
		}

		public static void main(String[] args) {
			float[] arrayA={0,1,2,3,4,5}, arrayB={50000,50000,0,0,0,20000};
			System.out.println(solution7(arrayA,arrayB));
	}
}
