package com.cg.assignment;

public class Problem9 {
	public static int solution9(int[][] Array) {
		int count=0,i,j,n=Array.length;
		for(i=1;i<n-1;i++){
			for(j=1;j<n-1;j++){
				if((Array[i][j-1]>Array[i][j] &&  Array[i][j]<Array[i][j+1] && Array[i-1][j]<Array[i][j] && Array[i][j]>Array[i+1][j]) ||
				(Array[i][j-1]<Array[i][j] && Array[i][j]>Array[i][j+1] && Array[i-1][j]>Array[i][j] && Array[i][j]<Array[i+1][j] ))
					count++;	
			}
		}
		return  count;
		
	}

	public static void main(String[] args) {
		int[][] Array={{0,1,9,3},{7,5,8,3},{9,2,9,4},{4,6,7,1}};
		System.out.println(solution9(Array));
	}
}
