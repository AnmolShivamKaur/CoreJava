package com.cg.mobile.exceptions;

public class PurchaseServicesDownException extends Exception{

	public PurchaseServicesDownException() {
		super();

	}

	public PurchaseServicesDownException(String message, Throwable cause,
			boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}

	public PurchaseServicesDownException(String message, Throwable cause) {
		super(message, cause);

	}

	public PurchaseServicesDownException(String message) {
		super(message);

	}

	public PurchaseServicesDownException(Throwable cause) {
		super(cause);

	}

}
