package com.cg.mobile.daoservices;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;



import com.cg.mobile.beans.Mobiles;
import com.cg.mobile.beans.PurchaseDetails;
import com.cg.mobile.util.ConnectionProvider;



public class PurchaseDaoImp implements PurchaseDao {
	private Connection conn=ConnectionProvider.getDBConnection();

	@Override
	public Mobiles save(Mobiles mobile) throws SQLException {
		try {
			conn.setAutoCommit(false);
			PreparedStatement pstmt1=conn.prepareStatement("insert into mobiles(mobileid , name, price ,quantity) values(?,?,?,?)");
			pstmt1.setInt(1, mobile.getMobileId());
			pstmt1.setString(2, mobile.getName());
			pstmt1.setInt(3, mobile.getPrice());
			pstmt1.setString(4, mobile.getQuantity());
			pstmt1.executeUpdate();
			
			PreparedStatement pstmt2=conn.prepareStatement("select max(mobileid) from mobiles");
			ResultSet rs=pstmt2.executeQuery();
			rs.next();
			int mobileid=rs.getInt(1);
			PreparedStatement pstmt3=conn.prepareStatement("insert into purchasedetails(mobileid,purchaseid,cname,mailid,phoneno,purchasedate) values(?,SEQ_PURCHASE_ID.nextval,?,?,?,SYSDATE)");
			pstmt3.setInt(1, mobileid);
			pstmt3.setString(2, mobile.getPurchase().getCname());
			pstmt3.setString(3,  mobile.getPurchase().getMailid());
			pstmt3.setString(4, mobile.getPurchase().getPhoneno());
			pstmt3.executeUpdate();
			
			PreparedStatement pstmt4=conn.prepareStatement("select max(purchaseid) from purchasedetails");
			ResultSet res=pstmt4.executeQuery();
			res.next();
			int purchaseid=res.getInt(1);
			conn.commit();
			mobile.getPurchase().setPurchaseid(purchaseid);
		return mobile;
	}catch(SQLException e){
		e.printStackTrace();
	}
		return mobile;
	}

	@Override
	public ArrayList<Mobiles> findAllMobileDetails() {
	
		return null;
	}





}
