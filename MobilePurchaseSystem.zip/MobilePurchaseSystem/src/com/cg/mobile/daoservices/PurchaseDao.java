package com.cg.mobile.daoservices;

import java.sql.SQLException;
import java.util.ArrayList;

import com.cg.mobile.beans.Mobiles;
import com.cg.mobile.beans.PurchaseDetails;

public interface PurchaseDao {
	Mobiles save(Mobiles mobile)throws SQLException;
	ArrayList<Mobiles> findAllMobileDetails();

}
