package com.cg.mobile.client;

import java.sql.Date;
import java.util.Scanner;

import com.cg.mobile.exceptions.PurchaseServicesDownException;
import com.cg.mobile.services.PurchaseServices;
import com.cg.mobile.services.PurchaseServicesImpl;

public class MainClass {

	public static void main(String[] args) throws PurchaseServicesDownException {
		PurchaseServices purchase=new PurchaseServicesImpl();
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter your choice from below menu");
		System.out.println("a) Insert the customer and purchase details.\n b)	Update the mobile quantity in mobiles table, once mobile is purchased by a customer.\nc)	View details of all mobiles available in the shop.\nd) Delete a mobile details based on mobile id.\ne)	Search mobiles based on price range.\nf)	Insert and search mobile service functionalities");
		char userChoice = sc.next().charAt(0);
		switch (Character.toUpperCase(userChoice)){
		case 'A':
		{
			System.out.println("mobile id,price,name,quantity,cname,mailid,phoneno,purchasedate");
			int mobileid=sc.nextInt();
			int price=sc.nextInt();
			String name=sc.nextLine();
			String quantity=sc.nextLine();
			String cname=sc.nextLine();
			String mailid=sc.nextLine();
			String phoneno=sc.nextLine();
			System.out.println("details"+purchase.acceptPurchaseDetails(cname, mailid, phoneno, mobileid, price, cname, quantity));
			
		}
		case 'B':
		{
			
		}
		case 'C':
		{
			
		}
		case 'D':
		{
			
		}
		case 'E':
		{
			
		}
		case 'F':
		{
			
		}
		default:
			System.out.println("Enter a valid choice.");
		}
	}

}
