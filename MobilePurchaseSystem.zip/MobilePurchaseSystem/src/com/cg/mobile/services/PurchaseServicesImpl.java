package com.cg.mobile.services;

import java.sql.Date;
import java.sql.SQLException;
import java.util.ArrayList;

import com.cg.mobile.beans.Mobiles;
import com.cg.mobile.beans.PurchaseDetails;
import com.cg.mobile.daoservices.PurchaseDao;
import com.cg.mobile.daoservices.PurchaseDaoImp;
import com.cg.mobile.exceptions.PurchaseServicesDownException;


public class PurchaseServicesImpl implements PurchaseServices {
	private PurchaseDao purchaseDao = new PurchaseDaoImp();

	@Override
	public Mobiles acceptPurchaseDetails(String cname, String mailid,
			String phoneno,int mobileid, int price,
			String name, String quantity) throws PurchaseServicesDownException {
		try{
		Mobiles mobile=new Mobiles(mobileid, price, name, quantity,new PurchaseDetails(cname, mailid, phoneno));
			purchaseDao.save(mobile);
			return mobile;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public int updateMobileQuantity() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public ArrayList<Mobiles> getAllmobileDetails() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void deleteMobileDetails(int mobileId) {
		// TODO Auto-generated method stub
		
	}

	
	
}
