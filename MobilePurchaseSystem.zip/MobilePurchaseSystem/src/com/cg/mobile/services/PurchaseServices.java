package com.cg.mobile.services;

import java.sql.Date;
import java.util.ArrayList;

import com.cg.mobile.beans.Mobiles;
import com.cg.mobile.exceptions.PurchaseServicesDownException;

public interface PurchaseServices {
	
	int updateMobileQuantity();
	ArrayList<Mobiles> getAllmobileDetails();
	void deleteMobileDetails(int mobileId);
	//ArrayList<Mobiles> getMobileDetails(int minRange,int maxRange);
	Mobiles acceptPurchaseDetails(String cname, String mailid, String phoneno,
			int mobileid, int price, String name, String quantity)
			throws PurchaseServicesDownException;
}
