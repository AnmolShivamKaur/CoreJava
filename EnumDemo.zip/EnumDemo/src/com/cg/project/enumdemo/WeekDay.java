package com.cg.project.enumdemo;

public enum WeekDay {
	MON(1,"Mon"),
	TUE(2,"Tue"),
	WED(3,"Wed"),
	THU(4,"Thu"),
	FRI(5,"Fri"),
	SAT(6,"Sat"),
	SUN(7,"Sun");
	
	private int dayIndex;
	private String dayName;
	
	private WeekDay() {
	}
	
	private WeekDay(int dayIndex, String dayName) {
		this.dayIndex = dayIndex;
		this.dayName = dayName;
	}

	public int getDayIndex() {
		return dayIndex;
	}
	public void setDayIndex(int dayIndex) {
		this.dayIndex = dayIndex;
	}
	public String getDayName() {
		return dayName;
	}
	public void setDayName(String dayName) {
		this.dayName = dayName;
	}
	
	
}
