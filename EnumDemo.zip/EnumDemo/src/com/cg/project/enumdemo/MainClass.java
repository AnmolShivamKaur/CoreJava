package com.cg.project.enumdemo;

public class MainClass {

	public static void main(String[] args) {
	Month month=Month.JAN;
	System.out.println(Month.JAN.getMonthIndex());
	WeekDay weekday=WeekDay.MON;
	System.out.println(WeekDay.MON.getDayIndex());
	}
}
