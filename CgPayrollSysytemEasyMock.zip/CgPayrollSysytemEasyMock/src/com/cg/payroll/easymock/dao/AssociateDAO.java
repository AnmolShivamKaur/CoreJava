package com.cg.payroll.easymock.dao;

import java.util.ArrayList;

import com.cg.payroll.easymock.beans.Associate;

public interface AssociateDAO {
	 Associate save(Associate associate);
	Associate findOne(int associateId);
	ArrayList<Associate> findAll();

}
