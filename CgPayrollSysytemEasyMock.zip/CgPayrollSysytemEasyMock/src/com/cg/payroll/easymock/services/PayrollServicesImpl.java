package com.cg.payroll.easymock.services;
import java.util.ArrayList;

import com.cg.payroll.easymock.beans.*;
import com.cg.payroll.easymock.dao.*;
import com.cg.payroll.easymock.beans.Associate;
import com.cg.payroll.easymock.exceptions.AssociateDetailsNotFoundException;
import com.cg.payroll.easymock.exceptions.PayrollServicesDownException;
import com.cg.payroll.easymock.exceptions.*;

public class PayrollServicesImpl implements PayrollServices{
	AssociateDAO associateDAO;
	


	public PayrollServicesImpl(AssociateDAO associateDAO) {
		super();
		this.associateDAO = associateDAO;
	}

	@Override
	public int acceptAssociateDetails(String firstName, String lastName,
			String emailId, String department, String designation,
			String pancard, int yearlyInvestmentUnder8oC, int basicSalary,
			int epf, int companyPf, int accountNumber, String bankName,
			String ifscCode) throws PayrollServicesDownException {
		Associate associate=new Associate(yearlyInvestmentUnder8oC,firstName, lastName,department, designation, pancard, emailId, 
				new BankDetails(accountNumber, bankName, ifscCode), new Salary(basicSalary, epf, companyPf));

		associate=associateDAO.save(associate);
		return associate.getAssociateId();
	}

	@Override
	public int calculateNetSalary(int associateId)
			throws AssociateDetailsNotFoundException,
			PayrollServicesDownException {
		Associate associate = getAssociateDetails(associateId);
		associate.getSalary().setHra((30*associate.getSalary().getBasicSalary())/100);
		associate.getSalary().setPersonalAllowance((20*associate.getSalary().getBasicSalary())/100);
		associate.getSalary().setOtherAllowance((20*associate.getSalary().getBasicSalary())/100);
		associate.getSalary().setConveyanceAllowance((10*associate.getSalary().getBasicSalary())/100);
		associate.getSalary().setGrossSalary(associate.getSalary().getBasicSalary()+associate.getSalary().
				getConveyanceAllowance()+associate.getSalary().getHra()+associate.getSalary().getOtherAllowance()+associate.getSalary().getPersonalAllowance());
		if(associate.getSalary().getGrossSalary()*12>0&&associate.getSalary().getGrossSalary()*12<250000)
			associate.getSalary().setMonthlyTax(0);
		else if(associate.getSalary().getGrossSalary()*12>250000&&associate.getSalary().getGrossSalary()*12<500000)
			associate.getSalary().setMonthlyTax((((associate.getSalary().getGrossSalary()*12)-250000)*5)/(100*12));
		else if(associate.getSalary().getGrossSalary()*12>500000&&associate.getSalary().getGrossSalary()*12<1000000)
			associate.getSalary().setMonthlyTax((250000*5)/(100*12)+(((associate.getSalary().getGrossSalary()*12)-500000)*20)/(100*12));
		else if(associate.getSalary().getGrossSalary()*12>1000000)
			associate.getSalary().setMonthlyTax((250000*5)/(100*12)+
					(500000*20)/(100*12)+(((associate.getSalary().getGrossSalary()*12)-1000000)*30)/(100*12));
		associate.getSalary().setNetSalary(associate.getSalary().getGrossSalary()-associate.getSalary().getMonthlyTax());

		return associate.getSalary().getNetSalary();

	}

	@Override
	public Associate getAssociateDetails(int associateId)
			throws AssociateDetailsNotFoundException,
			PayrollServicesDownException {
		Associate associate = associateDAO.findOne(associateId);
		if(associate==null) throw new AssociateDetailsNotFoundException("Associate Details Not Found");
		return associate;

	}
	@Override
	public ArrayList<Associate> getAllAssociateDetails()
			throws PayrollServicesDownException {
		return associateDAO.findAll();
	}

}
