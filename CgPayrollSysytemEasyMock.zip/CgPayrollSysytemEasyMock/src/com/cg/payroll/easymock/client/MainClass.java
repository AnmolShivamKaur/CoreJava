package com.cg.payroll.easymock.client;
import com.cg.payroll.easymock.exceptions.*;
import com.cg.payroll.easymock.services.*;
public class MainClass {

	public static void main(String[] args) throws AssociateDetailsNotFoundException, PayrollServicesDownException {
		/*Associate associate1=new Associate(101,15000,"Syam","Singh","Sr,Con","YTP","JDDU2664","sam@gmail.com");
		Associate associate2=new Associate(102,15780,"Raj","Singh","Sr,Con","YTP","EFDU2656","raj@gmail.com");
		Associate associate3=new Associate(103,25000,"Ram","Singh","Sr,Con","YTP","UKDU2656","ram@gmail.com");
		BankDetails bankDetails1=new BankDetails(235765884, "HDFC", "HDFC1882");
		BankDetails bankDetails2=new BankDetails(675765884, "ICICI", "ICIC01892");
		BankDetails bankDetails3=new BankDetails(935765884, "HDFC", "HDFC1882");
		System.out.println("Full Name= "+associate1.getFirstName()+" "+associate1.getLastName());
		System.out.println(Associate.getASSOCIATE_COUNT());
		Salary salary1=new Salary(15000, 2000, 500, 500, 1000, 200, 200, 2000, 1000, 25000, 30000);
		Salary salary2=new Salary(12000, 2500, 400, 500, 1200, 100, 250, 2000, 1000, 25000, 33000);
		Salary salary3=new Salary(14000, 2000, 500, 500, 1000, 200, 200, 2000, 1000, 25000, 30000);*/
		/*Associate associate=new Associate(101, 115000, "ram", "dev", "YTP", "Sr.con", "FPP345", "tirunaga@gmail.com", 
				new BankDetails(235467374, "HDFC", "HDFC1882"),
				new Salary(15000, 2000, 1000, 500));
		System.out.println(associate.getSalary().getBasicSalary());
		associate.getSalary().setHra((30*associate.getSalary().getBasicSalary())/100);
		associate.getSalary().setOtherAllowance((20*associate.getSalary().getBasicSalary())/100);
		associate.getSalary().setPersonalAllowance((25*associate.getSalary().getBasicSalary())/100);
		associate.getSalary().setConveyanceAllowance((10*associate.getSalary().getBasicSalary())/100);
		associate.getSalary().setGrossSalary(associate.getSalary().getBasicSalary()+associate.getSalary().getHra()+associate.getSalary().getOtherAllowance()+associate.getSalary().getPersonalAllowance()+associate.getSalary().getConveyanceAllowance());
		associate.getSalary().setMonthlyTax((((associate.getSalary().getGrossSalary()*12)*5)/100)/12);
		System.out.println(associate.getSalary().getMonthlyTax());
		System.out.println(associate.getSalary().getGrossSalary());
		associate.getSalary().setNetSalary(associate.getSalary().getGrossSalary()-associate.getSalary().getEpf()-associate.getSalary().getCompanyPf()-associate.getSalary().getMonthlyTax()-associate.getSalary().getGratuity());	*/
		PayrollServices payrollServices = new PayrollServicesImpl();
		payrollServices.acceptAssociateDetails("priyanka", "tirunagari", "tirunagari@gmail.com", "YTP", "Sr.Analyst", "EFPP2345", 15000, 15000, 2000, 1000, 234573849, "HDFC", "HDFC1882");
		System.out.println(payrollServices.getAssociateDetails(101));
		System.out.println(payrollServices.acceptAssociateDetails("priyanka", "tirunagari", "tirunagari@gmail.com", "YTP", "Sr.Analyst", "EFPP2345", 15000, 15000, 2000, 1000, 234573849, "HDFC", "HDFC1882"));	
		System.out.println(payrollServices.calculateNetSalary(101));
		System.out.println(payrollServices.getAllAssociateDetails());
	}

}
