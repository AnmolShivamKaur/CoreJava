package com.cg.project.collectiondemo;
import java.util.ArrayList;
import java.util.Collections;
public class ListClassesDemo {

	public static void arrayListClassWork() {
		ArrayList<Associate> associateList=new ArrayList<>();
		associateList.add(new Associate(101,15000,"Anmol"));
		associateList.add(new Associate(102,25000,"Simran"));
		associateList.add(new Associate(103,30000,"Jash"));
		Associate associateToSearch=new Associate(103,15000,"Jash");
		System.out.println(associateList.indexOf(associateToSearch));
		System.out.println(associateList.contains(associateToSearch));
		for(Associate associate:associateList)
			if(associate.getAssociateId()==103&&associate.getName().equals("Jash"));
				System.out.println(associateList);
/*	Collections.sort(associateList);
	Collections.sort(associateList, new AssociateComparator());*/
				
				Collections.sort(associateList,(asso1,asso2)->asso1.getSalary()-asso2.getSalary());
				System.out.println(associateList);

	}
}
