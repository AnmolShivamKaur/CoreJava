package com.cg.project.collectiondemo;

public class MainClass {

	public static void main(String[] args) {
		ListClassesDemo list=new ListClassesDemo();
		list.arrayListClassWork();
	}

}
