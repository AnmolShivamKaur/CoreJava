package com.cg.project.collectiondemo;

import java.util.Comparator;
import com.cg.project.collectiondemo.Associate;

public class AssociateComparator implements Comparator<Associate> {

	@Override
	public int compare(Associate arg1,Associate arg2) {
			return arg1.getSalary()-arg2.getSalary();
	}

}
